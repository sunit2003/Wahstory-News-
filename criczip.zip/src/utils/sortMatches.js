// // sortMatches.js
// import matchesData from "../../src/Data/matches.json"; // Adjust path as needed

// const sortMatches = () => {
//   const today = new Date();
//   today.setHours(0, 0, 0, 0); // Normalize today's date

//   const matches = matchesData.matches.map((match) => ({
//     ...match,
//     date: new Date(match.dateTimeGMT),
//   }));

//   const pastMatches = [];
//   const todayMatches = [];
//   const futureMatches = [];

//   matches.forEach((match) => {
//     if (match.date < today) {
//       pastMatches.push(match);
//     } else if (match.date.toDateString() === today.toDateString()) {
//       todayMatches.push(match);
//     } else {
//       futureMatches.push(match);
//     }
//   });

//   // Sort past matches in descending order
//   pastMatches.sort((a, b) => b.date - a.date);

//   // Sort future matches in ascending order
//   futureMatches.sort((a, b) => a.date - b.date);

//   return [...todayMatches, ...pastMatches, ...futureMatches];
// };

// export default sortMatches;

// sortMatches.js
// import matchesData from "../../src/Data/matches.json"; // Adjust path as needed

// const sortMatches = () => {
//   const today = new Date();
//   today.setHours(0, 0, 0, 0); // Normalize today's date

//   const matches = matchesData.matches.map((match) => ({
//     ...match,
//     date: new Date(match.dateTimeGMT),
//   }));

//   const iplMatches = [];
//   const nonIplMatches = [];

//   // Splitting matches into IPL and non-IPL categories
//   matches.forEach((match) => {
//     if (match.series.includes("Indian Premier League")) {
//       iplMatches.push(match);
//     } else {
//       nonIplMatches.push(match);
//     }
//   });

//   // Function to sort matches by past, today, and future
//   const sortDateCategories = (matchesArray) => {
//     const pastMatches = [];
//     const todayMatches = [];
//     const futureMatches = [];

//     matchesArray.forEach((match) => {
//       if (match.date < today) {
//         pastMatches.push(match);
//       } else if (match.date.toDateString() === today.toDateString()) {
//         todayMatches.push(match);
//       } else {
//         futureMatches.push(match);
//       }
//     });

//     // Sort each category individually
//     pastMatches.sort((a, b) => b.date - a.date); // Descending for past
//     futureMatches.sort((a, b) => a.date - b.date); // Ascending for future

//     // Combine sorted arrays: today, past, then future
//     return [...todayMatches, ...pastMatches, ...futureMatches];
//   };

//   // Apply sorting to IPL and non-IPL matches separately
//   const sortedIplMatches = sortDateCategories(iplMatches);
//   const sortedNonIplMatches = sortDateCategories(nonIplMatches);

//   // IPL matches first, then non-IPL matches
//   return [...sortedIplMatches, ...sortedNonIplMatches];
// };

// export default sortMatches;

import matchesData from "../../src/Data/matches.json"; // Ensure this is the correct path

const sortMatches = () => {
  const now = new Date(); // Current date and time

  // Filter and map only IPL matches
  const iplMatches = matchesData.matches
    .filter((match) => match.series.includes("Indian Premier League"))
    .map((match) => ({
      ...match,
      date: new Date(match.dateTimeGMT),
    }));

  // Function to sort matches by past, today, and future
  const sortIplMatches = (matchesArray) => {
    const pastMatches = [];
    const todayMatches = [];
    const futureMatches = [];

    matchesArray.forEach((match) => {
      if (match.date < now) {
        pastMatches.push(match);
      } else if (match.date.toDateString() === now.toDateString()) {
        todayMatches.push(match);
      } else {
        futureMatches.push(match);
      }
    });

    // Sort each category individually
    pastMatches.sort((a, b) => b.date - a.date); // Descending for past
    todayMatches.sort((a, b) => a.date - b.date); // Ascending for today
    futureMatches.sort((a, b) => a.date - b.date); // Ascending for future

    // Combine sorted arrays: today, past, then future
    return [...todayMatches, ...pastMatches, ...futureMatches];
  };

  // Return sorted IPL matches
  return sortIplMatches(iplMatches);
};

export default sortMatches;
