import React from "react";
import "./App.css";
import Navbar from "./user/component/Navigation/Navbar";
import Boxes from "./user/component/Content/Boxes";
import News from "./user/component/Content/News";

function App() {
  return (
    <>
      <Navbar />
      {/* <Boxes /> */}
      <News />
    </>
  );
}

export default App;
