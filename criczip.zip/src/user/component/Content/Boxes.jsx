// import React, { useEffect, useState } from "react";
// import sortMatches from "../../../utils/sortMatches";

// const Boxes = () => {
//   const [sortedMatches, setSortedMatches] = useState([]);

//   useEffect(() => {
//     setSortedMatches(sortMatches());

//     const intervalId = setInterval(() => {
//       setSortedMatches(sortMatches());
//     }, 60000);

//     return () => clearInterval(intervalId);
//   }, []);

//   return (
//     <div className="mt-8 container mx-auto px-4">
//       <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
//         {sortedMatches.length > 0 ? (
//           sortedMatches.map((match, index) => (
//             <div
//               key={index}
//               className="bg-white rounded-lg shadow-lg overflow-hidden flex flex-col"
//             >
//               <div className="p-4 flex-grow">
//                 <h5 className="text-lg font-bold">{match.series}</h5>
//                 <span className="block text-sm font-semibold text-blue-500">
//                   {match.matchType.toUpperCase()}
//                 </span>
//                 <div className="flex justify-between items-center mt-2 mb-4">
//                   <div>
//                     <img
//                       className="ml-[30%]"
//                       src={match.t1img}
//                       alt="Team 1"
//                       width="48px"
//                       height="48px"
//                     />
//                     <span className="ml-2 text-sm font-medium">{match.t1}</span>
//                     <div className="text-xs">{match.t1s}</div>
//                   </div>
//                   <div>
//                     <img
//                       className="ml-[30%]"
//                       src={match.t2img}
//                       alt="Team 2"
//                       width="48px"
//                       height="48px"
//                     />
//                     <span className="ml-2 text-sm font-medium">{match.t2}</span>
//                     <div className="text-xs">{match.t2s}</div>
//                   </div>
//                 </div>
//                 <p className="text-xs text-gray-500">
//                   Match Date: {new Date(match.dateTimeGMT).toLocaleString()}
//                 </p>
//                 <p className="text-xs font-semibold">{match.status}</p>
//               </div>
//             </div>
//           ))
//         ) : (
//           <p>No matches to display currently.</p>
//         )}
//       </div>
//     </div>
//   );
// };

// export default Boxes;

// import React, { useEffect, useState, useRef } from "react";
// import sortMatches from "../../../utils/sortMatches";

// const Boxes = () => {
//   const [sortedMatches, setSortedMatches] = useState([]);
//   const sliderRef = useRef(null);

//   useEffect(() => {
//     setSortedMatches(sortMatches());

//     const intervalId = setInterval(() => {
//       setSortedMatches(sortMatches());
//     }, 60000);

//     return () => clearInterval(intervalId);
//   }, []);

//   const scroll = (direction) => {
//     if (sliderRef.current) {
//       const { scrollLeft, clientWidth } = sliderRef.current;
//       const scrollTo =
//         direction === "left"
//           ? scrollLeft - clientWidth
//           : scrollLeft + clientWidth;
//       sliderRef.current.scrollTo({ left: scrollTo, behavior: "smooth" });
//     }
//   };

//   return (
//     <div className="mt-8 relative container mx-auto px-4">
//       <button
//         className="absolute left-0 top-1/2 transform -translate-y-1/2 z-20 bg-gray-800 text-white rounded-full p-3 hover:bg-gray-700 transition duration-300 ease-in-out"
//         onClick={() => scroll("left")}
//         aria-label="Scroll Left"
//       >
//         &#9664; {/* Unicode left arrow */}
//       </button>
//       <div
//         ref={sliderRef}
//         className="grid grid-flow-col auto-cols-max gap-4 overflow-x-auto py-4"
//         style={{ scrollSnapType: "x mandatory" }}
//       >
//         {sortedMatches.length > 0 ? (
//           sortedMatches.map((match, index) => (
//             <div
//               key={index}
//               className="bg-white rounded-lg shadow-lg overflow-hidden flex flex-col min-w-[300px]"
//               style={{ scrollSnapAlign: "start" }}
//             >
//               <div className="p-4 flex-grow">
//                 <h5 className="text-lg font-bold">{match.series}</h5>
//                 <span className="block text-sm font-semibold text-blue-500">
//                   {match.matchType.toUpperCase()}
//                 </span>
//                 <div className="flex justify-between items-center mt-2 mb-4">
//                   <div>
//                     <img
//                       className="ml-[30%]"
//                       src={match.t1img}
//                       alt="Team 1"
//                       width="48px"
//                       height="48px"
//                     />
//                     <span className="ml-2 text-sm font-medium">{match.t1}</span>
//                     <div className="text-xs">{match.t1s}</div>
//                   </div>
//                   <div>
//                     <img
//                       className="ml-[30%]"
//                       src={match.t2img}
//                       alt="Team 2"
//                       width="48px"
//                       height="48px"
//                     />
//                     <span className="ml-2 text-sm font-medium">{match.t2}</span>
//                     <div className="text-xs">{match.t2s}</div>
//                   </div>
//                 </div>
//                 <p className="text-xs text-gray-500">
//                   Match Date: {new Date(match.dateTimeGMT).toLocaleString()}
//                 </p>
//                 <p className="text-xs font-semibold">{match.status}</p>
//               </div>
//             </div>
//           ))
//         ) : (
//           <p className="text-center">No matches to display currently.</p>
//         )}
//       </div>
//       <button
//         className="absolute right-0 top-1/2 transform -translate-y-1/2 z-20 bg-gray-800 text-white rounded-full p-3 hover:bg-gray-700 transition duration-300 ease-in-out"
//         onClick={() => scroll("right")}
//         aria-label="Scroll Right"
//       >
//         &#9654; {/* Unicode right arrow */}
//       </button>
//     </div>
//   );
// };

// export default Boxes;

import React, { useEffect, useState, useRef } from "react";
import sortMatches from "../../../utils/sortMatches";
import AliceCarousel from "react-alice-carousel";
import "react-alice-carousel/lib/alice-carousel.css";
import { IconButton } from "@mui/material";
import ArrowBackIosIcon from "@mui/icons-material/ArrowBackIos";
import ArrowForwardIosIcon from "@mui/icons-material/ArrowForwardIos";

const Boxes = () => {
  const [sortedMatches, setSortedMatches] = useState([]);
  const carousel = useRef(null);

  useEffect(() => {
    setSortedMatches(sortMatches());

    const intervalId = setInterval(() => {
      setSortedMatches(sortMatches());
    }, 60000);

    return () => clearInterval(intervalId);
  }, []);

  const responsive = {
    0: { items: 1 },
    640: { items: 2 },
    1024: { items: 3 },
    1440: { items: 4 },
  };

  const items = sortedMatches.map((match, index) => (
    <div
      key={index}
      className="shadow-lg overflow-hidden flex flex-col h-64 select-none"
    >
      <div className="p-4 bg-[#212529] mx-2 rounded-xl flex-grow">
        <h5 className="text-lg font-bold">{match.series}</h5>
        <span className="block text-sm font-semibold text-blue-500">
          {match.matchType.toUpperCase()}
        </span>
        <div className="flex justify-between items-center mt-2 mb-4">
          <div>
            <img
              className="ml-[30%]"
              src={match.t1img}
              alt="Team 1"
              width="48px"
              height="48px"
            />
            <span className="ml-2 text-sm font-medium">{match.t1}</span>
            <div className="text-xs">{match.t1s}</div>
          </div>
          <div>
            <img
              className="ml-[30%]"
              src={match.t2img}
              alt="Team 2"
              width="48px"
              height="48px"
            />
            <span className="ml-2 text-sm font-medium">{match.t2}</span>
            <div className="text-xs">{match.t2s}</div>
          </div>
        </div>
        <p className="text-xs text-gray-500">
          Match Date: {new Date(match.dateTimeGMT).toLocaleString()}
        </p>
        <p className="text-xs font-semibold">{match.status}</p>
      </div>
    </div>
  ));

  return (
    <div className="relative mt-8 container mx-auto px-4">
      <AliceCarousel
        disableDotsControls
        disableButtonsControls
        autoPlay
        autoPlayInterval={3000}
        responsive={responsive}
        mouseTracking
        items={items}
        paddingLeft={50}
        paddingRight={50}
        ref={carousel}
      />
      <div className="absolute inset-y-0 left-0 flex items-center">
        <IconButton
          onClick={() => carousel.current.slidePrev()}
          className="!bg-gray-800 !text-white !p-2 hover:!bg-gray-700 transition duration-300 ease-in-out"
        >
          <ArrowBackIosIcon />
        </IconButton>
      </div>
      <div className="absolute inset-y-0 right-0 flex items-center">
        <IconButton
          onClick={() => carousel.current.slideNext()}
          className="!bg-gray-800 !text-white !p-2 hover:!bg-gray-700 transition duration-300 ease-in-out"
        >
          <ArrowForwardIosIcon />
        </IconButton>
      </div>
    </div>
  );
};

export default Boxes;
