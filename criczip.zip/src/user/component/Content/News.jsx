import React from "react";
import AliceCarousel from "react-alice-carousel";
import "react-alice-carousel/lib/alice-carousel.css";

const News = () => {
  const newsItems = [
    {
      image:
        "https://www.wahstory.com/wahcommunity/upload/feed/amazon-hist-header918187677.jpg",
      text: "Amazon has announced a groundbreaking investment to expand its renewable energy projects across Asia and Europe, aiming to achieve net-zero carbon emissions by 2040. This initiative includes launching new solar and wind farms, reinforcing Amazon's commitment to environmental sustainability.",
    },
    {
      image:
        "https://www.wahstory.com/wahcommunity/upload/feed/1697081114662858535011.png",
      text: "Apple has unveiled its latest iPhone model, featuring a revolutionary AI chip that enhances battery life and processing speed, setting new industry standards.",
    },
    {
      image:
        "https://www.sciencespo.fr/public/chaire-numerique/wp-content/uploads/2023/06/meta2.png",
      text: "Meta has introduced a new virtual reality platform, 'MetaWorld' aimed at transforming social interactions and professional collaborations through immersive experiences.",
    },
  ];

  const items = newsItems.map((item, index) => (
    <div key={index} className="relative w-full h-full select-none">
      <img
        src={item.image}
        alt={`News ${index + 1}`}
        className="w-full h-[27rem] object-cover"
      />
      <div className="absolute bottom-0 left-0 w-full p-10 bg-gradient-to-t from-black to-transparent text-white font-semibold">
        {item.text}
      </div>
    </div>
  ));

  return (
    <div className="mt-10 px-4">
      <div className="text-start text-4xl font-semibold mb-4 font-[FrankRuhlLibre]">
        LATEST NEWS :
      </div>
      <div className="flex w-full">
        <div className="w-1/2 h-[30vh] relative">
          <AliceCarousel
            animationType="fadeout"
            mouseTracking
            infinite
            autoPlay
            autoPlayInterval={2000}
            items={items}
            disableButtonsControls
            dotsClass="alice-carousel__dots"
          />
          <div className="mt-5">
            <h2 className="text-2xl font-[FrankRuhlLibre]">Top News</h2>
            <div className="w-full h-96 mt-5 overflow-y-auto grid grid-cols-2 gap-2">
              {/* Multiple news item divs */}
              <div className="bg-[#212529] p-4">
                <img
                  src="https://upload.wikimedia.org/wikipedia/commons/5/5a/Google_Headquarters_Google_Logo_%2852639793897%29.jpg"
                  alt=""
                />
                <h2>Google HQ launch</h2>
                <p>Details about the new Google headquarters...</p>
              </div>
              <div className="bg-[#212529] p-4">
                <img
                  src="https://assets.hardwarezone.com/img/2016/10/_A270254.jpg"
                  alt=""
                />
                <h2>More News Item</h2>
                <p>Description of another news item...</p>
              </div>
              <div className="bg-[#212529] p-4">
                <img
                  src="https://cdn.shopify.com/s/files/1/0520/8539/1547/files/starbase_texas_sign.jpg?v=1623302468"
                  alt=""
                />
                <h2>Another Headline</h2>
                <p>Further information on a relevant topic...</p>
              </div>
              <div className="bg-[#212529] p-4">
                <img
                  src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRnh2hBIHzCRUiXn813pZWT-qTTDdyo33Gq24_IiQrEUg&s"
                  alt=""
                />
                <h2>Another Headline</h2>
                <p>Further information on a relevant topic...</p>
              </div>
              <div className="bg-[#212529] p-4">
                <img
                  src="https://assets.hardwarezone.com/img/2016/10/_A270254.jpg"
                  alt=""
                />
                <h2>More News Item</h2>
                <p>Description of another news item...</p>
              </div>
            </div>
          </div>
        </div>

        <div className="w-1/2 pl-4">
          <div className="flex justify-between space-x-4">
            <div
              className="bg-[#212529] p-3 shadow rounded-lg"
              style={{ maxWidth: "400px" }}
            >
              <img
                className="object-cover w-full h-56 rounded-lg"
                src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQS-UNQj7zu00eD-AiTP7522rFgJNBG-7CfWA&s"
                alt=""
              />
              <h5 className="font-bold text-lg">
                Microsoft Expands Cloud Services
              </h5>
              <p
                className="text-white text-sm mt-2"
                style={{
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                  //   whiteSpace: "nowrap",
                }}
              >
                Microsoft has launched advanced cloud regions in Africa, aiming
                to boost global connectivity and local economies through
                enhanced cloud computing services.
              </p>
            </div>
            <div className="bg-[#212529] p-3 shadow rounded-lg ">
              <img
                className="object-cover w-[20rem] h-56 rounded-lg mx-auto"
                src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcScfEk8nUOS2fwhirQsRiRvo4Wo46-yGDm0fprW7MlAgw&s"
                alt=""
              />
              <h5 className="font-bold text-lg">
                OpenAI Releases New AI Model
              </h5>
              <p className="text-white text-sm mt-4">
                OpenAI has launched an advanced AI model designed to facilitate
                more nuanced and complex human-AI interactions, paving the way
                for significant advancements in natural language processing.
              </p>
            </div>
          </div>
          <div className="bg-[#212529] p-3 shadow rounded-lg mt-4">
            <img
              className=" rounded-xl"
              src="https://static.theprint.in/wp-content/uploads/2021/11/Blackrock-headquarters-in-New-York-U.S.-on-Wednesday-Oct.-13-2021.-BlackRock-gains-1.7-in-prema.jpg"
              alt=""
            />
            <h5 className="font-bold text-lg">
              BlackRock Boosts Sustainable Investments
            </h5>
            <p className="text-white text-sm mt-3">
              BlackRock has launched a new line of climate-focused investment
              funds aimed at accelerating the transition to a low-carbon
              economy, reaffirming its commitment to sustainable investing.
            </p>
          </div>
        </div>
      </div>
      <style jsx>{`
        .alice-carousel__dots {
          position: absolute;
          right: 40%;
          bottom: -10px;
        }
        .alice-carousel__dots-item {
          min-width: 10px;
          min-height: 10px;
          margin: 10px;
          border-radius: 20px;
          background: gray;
          opacity: 0.8;
          transition: opacity 0.5s, width 0.25s ease-in-out;
        }
        .alice-carousel__dots-item.__active {
          background: white !important;
          opacity: 1;
          border-radius: 20px;
          height: 5px;
          width: 60px;
        }
      `}</style>
    </div>
  );
};

export default News;
